import os
import sys
import argparse
import random

import time
import threading
from multiprocessing import Process

class run(object):
  'run for some nums'
  def __init__(self):
    self.all_cmd    = ['regr']
    self.__dict__.update(vars(args))
    self.workarea = ''
    self.testcase = ''
    self.lsf_cmd  = "bsub -Is"
  
  def colorize(self,text,color_code):
    print("\033[{};1m{}\033[0m".format(color_code,text))

  def red(self,text):
    self.colorize(text,31)

  def green(self,text):
    self.colorize(text,32)

  def blue(self,text):
    self.colorize(text,34)


  def check_env(self,envname):
    if os.getenv(envname) is None:
      self.red("[Error]: Pleas source workarea")
      sys.exit()
    else:
      return os.getenv(envname)

  def gen_path(self):
    #self.workarea = self.check_env('workarea') 
    #self.outpath  = os.path.join(self.workarea, 'out')
    #os.system("jm run -t {tc}".format(tc=self.testcase))
    self.blue("[INFO]: start comp")
    #os.system("python3 $WORKAREA/script/jm.py comp -mode {mode}".format(mode=self.mode))

  
  def do_comp(self):
    self.gen_path()
    #make_cmd =" ".join(['python3 $WORKAREA/script/jm.py comp -t', self.testcase])
    make_cmd =" ".join(['python3 $WORKAREA/script/jm.py comp -t', self.testcase])
    if self.tc is not None:
      make_cmd = " ".join([make_cmd, self.tc])
    else:
      slef.red("[Error]")
      sys.exit()

    if self.mode is not None:
      make_cmd = " ".join([make_cmd, self.mode])


    if self.seed is not None:
      make_cmd = " ".join([make_cmd, " -s ", self.seed])

    #verifier1
    if self.cov is True:
      make_cmd = " ".join([make_cmd, "-c"])


    self.blue("[INFO]: start comp")
    os.system(make_cmd) 

  def do_sim(self):
    self.gen_path()
    #make_cmd =" ".join(['python3 $WORKAREA/script/jm.py comp -t', self.testcase])
    make_cmd =" ".join(['python3 $WORKAREA/script/jm.py ncrun -t', self.testcase])
    if self.tc is not None:
      make_cmd = " ".join([make_cmd, self.tc])
    else:
      slef.red("[Error]")
      sys.exit()

    if self.mode is not None:
      make_cmd = " ".join([make_cmd, self.mode])

    if self.seed is not None:
      make_cmd = " ".join([make_cmd, " -s ", self.seed])

    if self.dump is True:
      make_cmd = " ".join([make_cmd, "-d"]) 
  
#verifier2
    if self.cov is True:
      make_cmd = " ".join([make_cmd, "-c"])


    self.blue("[INFO]: start sim")
    os.system(make_cmd) 

  def do_comp_thread(self):
    thread1 =threading.Thread(target=self.do_comp) 
    thread1.start()
    thread1.join()

  def do_sim_regr(self):
    time1=time.time()
    _processes=[]
    n = int(self.node)//int(self.cpu)
    b=int(self.node)
    a=int(self.cpu)
    if b==0 or b==1:
      n=1
      a=1
    if b==2:
      n=1
      a=2
    if b==3:
      n=1
      a=3
    print("n____{}".format(n))
    for i in range(0, n):
      for index in range(0, a):
        _process = Process(target=self.do_sim,args=(),name=self.tc)
        _process.start()
        print("___________________bk_name:{}".format(_process.name))
        _processes.append(_process)
      for _process in _processes:
        _process.join()

    time2=time.time()
    print("time consume {}s".format(time2-time1))
    print("sim_done___________")

  def gen_summary_report(self):
    string = ""
    string = string + "\033[34m\n"
    string = string + "+---------------------------------------------------------------------------------------+\n"
    string = string + "|                            Compilation/Simulation Summry                              |\n"
    string = string + "+---------------------------------------------------------------------------------------+\n"
    string = string + "| COMP_DONE|COMP_ERROR| NOT_RUN  |   PASS   |   FAIL   |   WARN   |  ABORT   |  TOTAL   |\n"
    string = string + "+---------------------------------------------------------------------------------------+\n"
    string = string + "#{}\n".format("a,b,c")
    string = string + "+---------------------------------------------------------------------------------------+\n"
    string = string + "\033[0m\n"

    print(string)
    

  def main(self):
    if self.notcomp is False:
      self.do_comp_thread()
      self.do_sim_regr()
    else:
      self.do_sim_regr()

    
usage_help = ''' 
    run option
'''
cmd_help='''
    cmd option
'''

if __name__=='__main__':
  parser = argparse.ArgumentParser(description=usage_help,formatter_class=argparse.RawTextHelpFormatter)
  #parser.add_argument('cmd', help=cmd_help)
  parser.add_argument('-d','--dump',action='store_true',help='dump waveform option')
  parser.add_argument('-p','--notcomp',action='store_true',help='not comp option')
  parser.add_argument('-c','--cov',action='store_true',help='enable vcs coverage option')   #verifier3
  parser.add_argument('-t', '--tc',default=None,metavar='testcase',help='testcase name')
  parser.add_argument('-n', '--node',type=int, default=1,metavar='num',help='the total number of sim') 
  parser.add_argument('-u', '--cpu',type=int, default=4,metavar='num',help='the number of parraller cpu') 
  parser.add_argument('-mode','--mode',metavar='mode',help='for multi mode testbench,default=default')
  parser.add_argument('-s','--seed',default=None,metavar='seed',help='testcase seed')
  args = parser.parse_args()
  kwargs=(vars(args))
  run=run()
  run.main()
